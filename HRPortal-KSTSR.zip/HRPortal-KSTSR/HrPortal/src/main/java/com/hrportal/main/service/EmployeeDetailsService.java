package com.hrportal.main.service;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrportal.main.pojo.EmployeeDetails;
import com.hrportal.main.pojo.RequirementDetails;
import com.hrportal.main.repository.EmployeeDetailsRepository;
import com.hrportal.main.repository.EmployeeDetailsRepositoryInterface;
import com.hrportal.main.repository.RequirementDetailsRepository;
import com.hrportal.main.repository.RequirementDetailsRepositoryInterface;

@Service
public class EmployeeDetailsService implements EmployeeDetailsServiceInterface {

	@Autowired
	private EmployeeDetailsRepositoryInterface employeeDetailsRepositoryInterface;
	@Autowired
	private RequirementDetailsRepositoryInterface requirementDetailsRepositoryInterface;

	@Override
	public boolean addEmployeeDetails(EmployeeDetails employeeDetails) {
		return employeeDetailsRepositoryInterface.addEmployeeDetails(employeeDetails);
	}

	@Override
	public boolean updateEmployeeDetails(EmployeeDetails employeeDetails) {
		return employeeDetailsRepositoryInterface.updateEmployeeDetails(employeeDetails);
	}

	@Override
	public boolean deleteEmployeeDetails(int employeeId) {
		return employeeDetailsRepositoryInterface.deleteEmployeeDetails(employeeId);
	}

	@Override
	public EmployeeDetails getEmployeeDetailsByEmployeeId(int employeeId) {
		return employeeDetailsRepositoryInterface.getEmployeeDetailsByEmployeeId(employeeId);
	}

	@Override
	public List<EmployeeDetails> getAllEmployeeDetails() {
		return employeeDetailsRepositoryInterface.getAllEmployeeDetails();
	}

	@Override
	public EmployeeDetails getEmployeeDetailsByLoginId(int loginId) {
		return employeeDetailsRepositoryInterface.getEmployeeDetailsByLoginId(loginId);
	}

	@Override
	public List<EmployeeDetails> getEmployeeOnBench(RequirementDetails requirementDetails) {
		return employeeDetailsRepositoryInterface.getEmployeeOnBench(requirementDetails);
	}

	@Override
	public boolean updateEmployeeProjectId(EmployeeDetails employeeDetails) {
		boolean result = employeeDetailsRepositoryInterface.updateEmployeeProjectId(employeeDetails);
		int jobId = employeeDetails.getMgrId();
		int requiredEmployee = requirementDetailsRepositoryInterface.getRequiredNoOfEmployeesByJobId(jobId);
		requiredEmployee = requiredEmployee - 1;
		RequirementDetails requirementDetails = requirementDetailsRepositoryInterface.getRequirmentDetailsByJobId(jobId);
		requirementDetails.setRequiredNoOfEmployees(requiredEmployee);
		boolean updateRequiredNumberOfEmployee = requirementDetailsRepositoryInterface.updateRequirmentDetails(requirementDetails);
		if (result && updateRequiredNumberOfEmployee) {
			return result;

		}
		return false;

	}

}
