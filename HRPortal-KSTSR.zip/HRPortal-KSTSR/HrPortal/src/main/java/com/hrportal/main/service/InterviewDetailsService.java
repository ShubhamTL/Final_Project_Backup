package com.hrportal.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.hrportal.main.pojo.InterviewDetails;
import com.hrportal.main.repository.CandidateDetailsRepository;
import com.hrportal.main.repository.CandidateDetailsRepositoryInterface;
import com.hrportal.main.repository.InterviewDetailsRepositoryInterface;

@Service
public class InterviewDetailsService implements InterviewDetailsServiceInterface {
	@Autowired
	private InterviewDetailsRepositoryInterface interviewDetailsRepositoryInterface;
	@Autowired
	private CandidateDetailsRepositoryInterface candidateDetailsRepositoryInterface;
	@Autowired
	private JavaMailSender javaMailSender;
	@Value("${spring.mail.username}")
	private String sender;

	@Override
	public boolean addInterviewDetails(InterviewDetails interviewDetails) {
		candidateDetailsRepositoryInterface.updateCandidateApplicationStatusByCandidateId(interviewDetails.getInterviewStatus(),interviewDetails.getCandidateDetails().getCandidateId());
		return interviewDetailsRepositoryInterface.addInterviewDetails(interviewDetails);

	}

	@Override
	public boolean updateInterviewDetails(InterviewDetails interviewDetails) {
		return interviewDetailsRepositoryInterface.updateInterviewDetails(interviewDetails);
	}

	@Override
	public boolean deleteInterviewDetails(int interviewId) {
		return interviewDetailsRepositoryInterface.deleteInterviewDetails(interviewId);
	}

	@Override
	public InterviewDetails getInterviewDetailsByinterviewId(int interviewId) {
		return interviewDetailsRepositoryInterface.getInterviewDetailsByinterviewId(interviewId);
	}

	@Override
	public List<InterviewDetails> getAllInterviewDetails() {
		return interviewDetailsRepositoryInterface.getAllInterviewDetails();
	}

	@Override
	public List<InterviewDetails> getInterviewDetailsBySelectedStatus() {
		return interviewDetailsRepositoryInterface.getInterviewDetailsBySelectedStatus();
	}

	@Override
	public List<InterviewDetails> getInterviewDetailsByRejectedStatus() {
		return interviewDetailsRepositoryInterface.getInterviewDetailsByRejectedStatus();
	}

@Override
	public boolean sendMailByInterviewStatus(InterviewDetails interviewDetails) {
	        try {
	            SimpleMailMessage mailMessage= new SimpleMailMessage();
	            mailMessage.setFrom(sender);
	            mailMessage.setTo(interviewDetails.getCandidateDetails().getEmailId());
	            mailMessage.setSubject("Interview Result");
	            if(interviewDetails.getInterviewStatus().equalsIgnoreCase("SELECTED")){
	            	mailMessage.setText("Thanks for applying to work at our organization. our focus has always been on finding the best people and developing them into the technology leaders of tomorrow.You have been selected for this position Thanks again for your interest");
	            javaMailSender.send(mailMessage);
	            }
	            if(interviewDetails.getInterviewStatus().equalsIgnoreCase("REJECTED")) {
	             	mailMessage.setText("Thanks for applying to work at our organization. our focus has always been on finding the best people and developing them into the technology leaders of tomorrow.We've had very competitive pool of cadidates and unfortunately, you hav not been selected for this position Thanks again for your interest");
	            javaMailSender.send(mailMessage);
	            }
	            return true;
	        }
	        catch (Exception e) {
	            return false;
	        }
	
}
}
