package com.hrportal.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrportal.main.pojo.EmployeeDetails;
import com.hrportal.main.pojo.RequirementDetails;
import com.hrportal.main.repository.RequirementDetailsRepositoryInterface;

@Service
public class RequirementDetailsService implements RequirementDetailsServiceInterface {

	@Autowired
	private RequirementDetailsRepositoryInterface requirementDetailsRepositoryInterface;

	@Override
	public boolean addRequirmentDetails(RequirementDetails requirementDetails) {
		return requirementDetailsRepositoryInterface.addRequirmentDetails(requirementDetails);
	}

	@Override
	public boolean updateRequirmentDetails(RequirementDetails requirementDetails) {
		return requirementDetailsRepositoryInterface.updateRequirmentDetails(requirementDetails);
	}

	@Override
	public boolean deleteRequirmentDetailsDetails(int jobId) {
		return requirementDetailsRepositoryInterface.deleteRequirmentDetailsDetails(jobId);
	}

	@Override
	public RequirementDetails getRequirmentDetailsByJobId(int jobId) {
		return requirementDetailsRepositoryInterface.getRequirmentDetailsByJobId(jobId);
	}

	@Override
	public List<RequirementDetails> getAllRequirmentDetails() {
		return requirementDetailsRepositoryInterface.getAllRequirmentDetails();
	}

	@Override
	public List<RequirementDetails> getSingleRequestByProjectId(int projectId) {
		return requirementDetailsRepositoryInterface.getSingleRequestByProjectId(projectId);
	}

	@Override
	public int getRequiredNoOfEmployeesByJobId(int jobId) {
		return requirementDetailsRepositoryInterface.getRequiredNoOfEmployeesByJobId(jobId);
	}

	@Override
	public boolean updateRequirementdetailsStatus(RequirementDetails requirementDetails) {
		return requirementDetailsRepositoryInterface.updateRequirementdetailsStatus(requirementDetails);
	}


	@Override
	public boolean updateRequirementdetailsStatusToAccepted(RequirementDetails requirementDetails) {
		return requirementDetailsRepositoryInterface.updateRequirementdetailsStatusToAccepted(requirementDetails);
	}
	
	@Override
	public List<RequirementDetails> getRequirementDetailsByAcceptedStatus() {
		return requirementDetailsRepositoryInterface.getRequirementDetailsByAcceptedStatus();
	}
	
	@Override
	public List<RequirementDetails> getRequirementDetailsBySendToHrStatusStatus() {
		return requirementDetailsRepositoryInterface.getRequirementDetailsBySendToHrStatusStatus();
	}

	@Override
	public List<RequirementDetails> getRequirementDetailsByInProcessStatus() {
		return requirementDetailsRepositoryInterface.getRequirementDetailsByInProcessStatus();
	}
}