package com.hrportal.main.repository;

import java.util.List;

import com.hrportal.main.pojo.EmployeeDetails;
import com.hrportal.main.pojo.RequirementDetails;

public interface EmployeeDetailsRepositoryInterface {

	public boolean addEmployeeDetails(EmployeeDetails employeeDetails);
	public boolean updateEmployeeDetails(EmployeeDetails employeeDetails);
	public boolean deleteEmployeeDetails(int employeeId);
	public EmployeeDetails getEmployeeDetailsByEmployeeId(int employeeId);
	public  List<EmployeeDetails> getAllEmployeeDetails();
	public EmployeeDetails getEmployeeDetailsByLoginId(int loginId);
	public List<EmployeeDetails> getEmployeeOnBench(RequirementDetails requirementDetails);
	public boolean updateEmployeeProjectId(EmployeeDetails employeeDetails);
}
