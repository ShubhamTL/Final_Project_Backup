package com.hrportal.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrportal.main.pojo.FileDetails;
import com.hrportal.main.repository.FileDetailsRepository;
import com.hrportal.main.repository.FileDetailsRepositoryInterface;

@Service
public class FileDetailsService implements FileDetailsServiceInterface {

	@Autowired
	private FileDetailsRepositoryInterface fileDetailsRepositoryInterface;

	@Override
	public int addFileDetails(FileDetails fileDetails) {
		return fileDetailsRepositoryInterface.addFileDetails(fileDetails);
	}

	@Override
	public boolean updateFileDetails(FileDetails fileDetails) {
		return fileDetailsRepositoryInterface.updateFileDetails(fileDetails);
	}

	@Override
	public boolean deleteFileDetailsDetails(int fileId) {
		return fileDetailsRepositoryInterface.deleteFileDetailsDetails(fileId);
	}

	@Override
	public FileDetails getFileDetailsByFileId(int fileId) {
		return fileDetailsRepositoryInterface.getFileDetailsByFileId(fileId);
	}

	@Override
	public List<FileDetails> getAllFileDetails() {
		return fileDetailsRepositoryInterface.getAllFileDetails();
	}

}
