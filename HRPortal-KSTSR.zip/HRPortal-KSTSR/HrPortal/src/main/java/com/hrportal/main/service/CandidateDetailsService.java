package com.hrportal.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrportal.main.pojo.CandidateDetails;
import com.hrportal.main.pojo.EmployeeDetails;
import com.hrportal.main.pojo.LoginDetails;
import com.hrportal.main.pojo.RequirementDetails;
import com.hrportal.main.repository.CandidateDetailsRepository;
import com.hrportal.main.repository.CandidateDetailsRepositoryInterface;
import com.hrportal.main.repository.RequirementDetailsRepositoryInterface;

@Service
public class CandidateDetailsService implements CandidateDetailsServiceInterface {

	@Autowired
	private CandidateDetailsRepositoryInterface candidateDetailsRepositoryInterface;
	@Override
	public boolean addCandidateDetails(CandidateDetails candidateDetails) {
		return candidateDetailsRepositoryInterface.addCandidateDetails(candidateDetails);
	}

	@Override
	public boolean updateCandidateDetails(CandidateDetails candidateDetails) {
		return candidateDetailsRepositoryInterface.updateCandidateDetails(candidateDetails);
	}

	@Override
	public boolean deleteCandidateDetailsDetails(int candidateId) {
		return candidateDetailsRepositoryInterface.deleteCandidateDetailsDetails(candidateId);
	}

	@Override
	public CandidateDetails getCandidateDetailsByCandidateId(int candidateId) {
		return candidateDetailsRepositoryInterface.getCandidateDetailsByCandidateId(candidateId);
	}


	@Override
	public List<CandidateDetails> getAllCandidateDetails() {
		return candidateDetailsRepositoryInterface.getAllCandidateDetails();
	}

	@Override
	public boolean updateCandidateDetailsStatusById(CandidateDetails candidateDetails) {
		return candidateDetailsRepositoryInterface.updateCandidateDetailsStatusById(candidateDetails)	;
	}
	
	@Override
	public List<CandidateDetails> getCandidateDetailsBySendToInterviewerStatus() {
		return candidateDetailsRepositoryInterface.getCandidateDetailsBySendToInterviewerStatus();
	}
	
	@Override
	public boolean updateCandidateApplicationStatusByCandidateId(String applicationStatus,int candidateId) {
		return candidateDetailsRepositoryInterface.updateCandidateApplicationStatusByCandidateId(applicationStatus, candidateId);
	}

	@Override
	public List<CandidateDetails> getCandidateDetailsBySelectedStatus() {
		return candidateDetailsRepositoryInterface.getCandidateDetailsBySelectedStatus();
	}

	@Override
	public List<CandidateDetails> getCandidateDetailsByRejectedStatus() {
		return candidateDetailsRepositoryInterface.getCandidateDetailsByRejectedStatus();
	}

	@Override
	public List<CandidateDetails> getCandidateDetailsByInProcessStatus() {
		return candidateDetailsRepositoryInterface.getCandidateDetailsByInProcessStatus();
	}

}
