package com.hrportal.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.hrportal.main.pojo.RequirementDetails;
import com.hrportal.main.pojo.EmployeeDetails;
import com.hrportal.main.pojo.ProjectMaster;
import com.hrportal.main.service.RequirementDetailsServiceInterface;
import com.hrportal.main.service.ProjectMasterServiceInterface;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("requirementdetails")
public class RequirementDetailsController {

	@Autowired
	private RequirementDetailsServiceInterface requirementDetailsServiceInterface;

	@RequestMapping(value = "requirementdetailbyprojectid/{projectid}", method = RequestMethod.GET)
	public @ResponseBody List<RequirementDetails> getSingleRequirementDetailByProjectId(@PathVariable int projectid) {
		return requirementDetailsServiceInterface.getSingleRequestByProjectId(projectid);
	}

	@RequestMapping(value = "requirementdetail", method = RequestMethod.GET)
	public @ResponseBody List<RequirementDetails> getAllJobRequestDetails() {
		return requirementDetailsServiceInterface.getAllRequirmentDetails();
	}

	@RequestMapping(value = "/requirementdetail/{jobId}", method = RequestMethod.GET)
	public @ResponseBody RequirementDetails getProjectMasterById(@PathVariable("jobId") int jobId) {
		return requirementDetailsServiceInterface.getRequirmentDetailsByJobId(jobId);
	}

	@RequestMapping(value = "/requirementdetail", method = RequestMethod.POST)
	public boolean addRequirementDetails(@RequestBody RequirementDetails requirementDetails) {
		return requirementDetailsServiceInterface.addRequirmentDetails(requirementDetails);
	}

	@RequestMapping(value = "/requirementdetail", method = RequestMethod.PUT)
	public @ResponseBody boolean updateRequirementDetails(@RequestBody RequirementDetails requirementDetails) {
		return requirementDetailsServiceInterface.updateRequirmentDetails(requirementDetails);
	}

	@RequestMapping(value = "/requirementdetail/{jobId}", method = RequestMethod.DELETE)
	public @ResponseBody boolean deleteRequirementDetails(@PathVariable("jobId") int jobId) {
		return requirementDetailsServiceInterface.deleteRequirmentDetailsDetails(jobId);
	}

	@RequestMapping(value = "/updaterequirementdetailstatus", method = RequestMethod.PUT)
	public @ResponseBody boolean updateRequirementdetailsStatus(@RequestBody RequirementDetails requirementDetails) {
		return requirementDetailsServiceInterface.updateRequirementdetailsStatus(requirementDetails);
	}


	@RequestMapping(value = "/updaterequirementdetailstatustoaccepted", method = RequestMethod.PUT)
	public @ResponseBody boolean updateRequirementdetailsStatusToAccepted(
			@RequestBody RequirementDetails requirementDetails) {
		return requirementDetailsServiceInterface.updateRequirementdetailsStatusToAccepted(requirementDetails);
	}

	@RequestMapping(value = "requirementdetailbyacceptedstatus", method = RequestMethod.GET)
	public @ResponseBody List<RequirementDetails> getRequirementDetailsByAcceptedStatus() {
		return requirementDetailsServiceInterface.getRequirementDetailsByAcceptedStatus();
	}
	
	
	@RequestMapping(value = "requirementdetailbysendtohrstatus", method =RequestMethod.GET)
	public @ResponseBody List<RequirementDetails> getRequirementDetailsBySendToHrStatusStatus() {
		return requirementDetailsServiceInterface.getRequirementDetailsBySendToHrStatusStatus();
	}

	@RequestMapping(value = "requirementdetailbyinprocessstatus", method =RequestMethod.GET)
	public @ResponseBody List<RequirementDetails> getRequirementDetailsByInProcessStatus() {
		return requirementDetailsServiceInterface.getRequirementDetailsByInProcessStatus();
	}
}
