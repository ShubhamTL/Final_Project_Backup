package com.hrportal.main.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.hrportal.main.pojo.EmployeeDetails;
import com.hrportal.main.pojo.FileDetails;
import com.hrportal.main.service.EmployeeDetailsServiceInterface;
import com.hrportal.main.service.FileDetailsServiceInterface;

@RestController
@CrossOrigin(origins = "*")

@RequestMapping("filedetails")
public class FileDetailsController {

	@Autowired
	private FileDetailsServiceInterface filesDetailsService;

	@RequestMapping(value = "filesdetails", method = RequestMethod.POST)
	public int newFilesDetails(@RequestParam("file") MultipartFile file) {
		try {
			FileDetails filesDetails = new FileDetails();
			filesDetails.setFileType(file.getContentType());
			filesDetails.setFileName(file.getOriginalFilename());
			filesDetails.setUploadFile(file.getBytes());
			return filesDetailsService.addFileDetails(filesDetails);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return 0;

	}

//	@RequestMapping(value = "filesdetails/{fileId}", method = RequestMethod.DELETE)
//	public boolean deleteFilesDetails(@PathVariable int fileId) {
//		return filesDetailsService.deleteFileDetailsByFileId(fileId);
//	}

//	@RequestMapping(value = "filesdetails", method = RequestMethod.PUT)
//	public FilesDetails updateFilesDetails(@RequestParam("file") MultipartFile file,
//			@RequestParam("fileId") int fileId) {
//		FilesDetails filesDetails = new FilesDetails();
//		try {
//			filesDetails.setFileId(fileId);
//			filesDetails.setFileContentType(file.getContentType());
//			filesDetails.setFileName(file.getOriginalFilename());
//			filesDetails.setFileContent(file.getBytes());
//			logger.info(filesDetails.toString());
//			filesDetailsService.updateFileDetails(filesDetails);
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//		return filesDetails;
//
//	}

	@RequestMapping(value = "filesdetails/all", method = RequestMethod.GET)
	public List<FileDetails> getAllFilesDetails() {
		return filesDetailsService.getAllFileDetails();
	}

	@RequestMapping(value = "filesdetails/{fileId}", method = RequestMethod.GET)
	public ResponseEntity<Resource> getSingleFilesDetails(@PathVariable int fileId) {
		FileDetails filesDetails = filesDetailsService.getFileDetailsByFileId(fileId);
		return ResponseEntity.ok().contentType(MediaType.parseMediaType(filesDetails.getFileType()))
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filesDetails.getFileName())
				.body(new ByteArrayResource(filesDetails.getUploadFile()));
	}

}
