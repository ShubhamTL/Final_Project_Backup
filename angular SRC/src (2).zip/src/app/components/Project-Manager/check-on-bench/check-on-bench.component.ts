import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/employee-details';
import { RequirementDetails } from 'src/app/pojo/requirement-details';
import { EmployeeDetailsService } from 'src/app/services/employee-details.service';
import { RequirementDetailsService } from 'src/app/services/requirement-details.service';

@Component({
  selector: 'app-check-on-bench',
  templateUrl: './check-on-bench.component.html',
  styleUrls: ['./check-on-bench.component.css']
})
export class CheckOnBenchComponent implements OnInit {

  jobId: number = 0;
  requirmentDetails: RequirementDetails = new RequirementDetails();
  benchEmployee: EmployeeDetails[] = [];
  employee : EmployeeDetails = new EmployeeDetails();
  projectId:number=0;
  hidden:boolean=false;
  sent:boolean=false;
  recordFound:boolean=false

  constructor(private employeeDetailsService: EmployeeDetailsService, private requirementDetailsService: RequirementDetailsService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit(): void {
    this.employee =  JSON.parse(sessionStorage.getItem('employee') || '{}');
    this.projectId= this.employee.projectMaster.projectId;
    this.jobId = this.route.snapshot.params['jobId'];
    this.requirementDetailsService.getSinglRequirementDetails(this.jobId).subscribe(
      data => {
        this.requirmentDetails = data;
        this.checkOnBench(this.requirmentDetails);
      }
    );

    
  }

  checkOnBench(requirementDetails : RequirementDetails) {
    this.employeeDetailsService.getEmployeeOnBench(requirementDetails).subscribe(data => {
      if(data.length>0){
        this.recordFound=true;
      this.benchEmployee = data;
      }
      else
      {
        this.recordFound=false;
      }
   
    }
    );
  }
  assignProject(employee:EmployeeDetails){
    employee.projectMaster.projectId=this.projectId;
    employee.mgrId=this.requirmentDetails.jobId;
     this.employeeDetailsService.assignProjectByemployeeId(employee).subscribe(data => {
       this.requirmentDetails.requiredNoOfEmployees = this.requirmentDetails.requiredNoOfEmployees - 1;
     });
     this.hidden=true;
  }
  sendToHr(){
    this.sent=true;
   this.requirementDetailsService.sendToHrUpdateByJobId(this.requirmentDetails).subscribe(data => {
    
   } 
    );
  }
  goToHome()
  { 
    this.router.navigate(['projectmanagerhome/updatejobrequestdetails']);
  }
  reLoadData(){

  }
}
