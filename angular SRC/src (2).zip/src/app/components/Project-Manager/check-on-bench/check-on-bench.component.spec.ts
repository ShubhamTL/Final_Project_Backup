import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckOnBenchComponent } from './check-on-bench.component';

describe('CheckOnBenchComponent', () => {
  let component: CheckOnBenchComponent;
  let fixture: ComponentFixture<CheckOnBenchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CheckOnBenchComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckOnBenchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
