import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/employee-details';
import { RequirementDetails } from 'src/app/pojo/requirement-details';
import { RequirementDetailsService } from 'src/app/services/requirement-details.service';

@Component({
  selector: 'app-update-job-request',
  templateUrl: './update-job-request.component.html',
  styleUrls: ['./update-job-request.component.css']
})
export class UpdateJobRequestComponent implements OnInit {

  requirementDetails: RequirementDetails = new RequirementDetails();
  employee: EmployeeDetails = new EmployeeDetails();
  allJobRequest: RequirementDetails[] = [];
  projectId: number = 0;
  hide: boolean = false;
  recordFound:boolean=false;


  constructor(private requirmentDetailsService: RequirementDetailsService, private router: Router) {

  }

  ngOnInit(): void {
    this.employee = JSON.parse(sessionStorage.getItem('employee') || '{}');
    this.projectId = this.employee.projectMaster.projectId;
    this.reloadData();
  }

  updateJobRequest(jobId: number) {
    this.router.navigate(['/updateJobRequest', jobId]);
  }

  reloadData() {
    this.requirmentDetailsService.getRequirmentByProjectId(this.projectId).subscribe(data => {
      if(data.length>0){
      this.allJobRequest = data;
      this.recordFound=true;
   
      
      }
    }
    );
  }
  checkOnBench(jobId: number) {
    this.hide = true;
    this.employee.mgrId=jobId;
    this.router.navigate(['/projectmanagerhome/checkonbench', jobId]);
  
    
  }

 
}
