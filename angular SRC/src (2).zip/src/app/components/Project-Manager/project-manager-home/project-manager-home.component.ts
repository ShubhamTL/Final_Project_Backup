import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/employee-details';
import { RequirementDetails } from 'src/app/pojo/requirement-details';
import { ProjectMasterService } from 'src/app/services/project-master.service';
import { RequirementDetailsService } from 'src/app/services/requirement-details.service';

@Component({
  selector: 'app-project-manager-home',
  templateUrl: './project-manager-home.component.html',
  styleUrls: ['./project-manager-home.component.css']
})
export class ProjectManagerHomeComponent implements OnInit {

  hide: boolean = true;

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  
  change() {
    this.hide = false;
  }

  logout(){
    this.router.navigate(['logindetails'])
  }
}
