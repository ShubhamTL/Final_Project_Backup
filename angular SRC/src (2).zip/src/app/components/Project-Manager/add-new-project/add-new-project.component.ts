import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProjectMaster } from 'src/app/pojo/project-master';
import { ProjectMasterService } from 'src/app/services/project-master.service';

@Component({
  selector: 'app-add-new-project',
  templateUrl: './add-new-project.component.html',
  styleUrls: ['./add-new-project.component.css']
})
export class AddNewProjectComponent implements OnInit {
  submitted: boolean = false;
  result: boolean = false;
  projectMaster:ProjectMaster=new ProjectMaster();
  constructor(private projectMasterService:ProjectMasterService, router: Router) { }

  ngOnInit(): void {
  }
  onFormSubmit() {
    this.submitted = true;
    console.log(this.projectMaster);
    this.projectMasterService.addNewProject(this.projectMaster).subscribe(data => {
      this.result = data;
      console.log(data);
      console.log(this.result);
    }
    );
  }

}
