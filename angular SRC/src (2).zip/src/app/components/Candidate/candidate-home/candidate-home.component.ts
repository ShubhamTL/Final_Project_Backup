import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/employee-details';
import { RequirementDetails } from 'src/app/pojo/requirement-details';
import { CandidateDetailsService } from 'src/app/services/candidate-details.service';
import { RequirementDetailsService } from 'src/app/services/requirement-details.service';

@Component({
  selector: 'app-candidate-home',
  templateUrl: './candidate-home.component.html',
  styleUrls: ['./candidate-home.component.css']
})
export class CandidateHomeComponent implements OnInit {

  mentDetails: RequirementDetails = new RequirementDetails();
  employee: EmployeeDetails = new EmployeeDetails();
  acceptedRequest: RequirementDetails[] = [];
  apply: boolean = true;
  jobId: number = 0;
  constructor(private requirmentDetailsService: RequirementDetailsService, private candidateDetailsService: CandidateDetailsService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.reloadData();

  }

  reloadData() {
    this.requirmentDetailsService.getRequirementByAcceptedStatus().subscribe(data => {
      this.acceptedRequest = data;
     
    }
    );
  }
  applyForJob(requirementDetails : RequirementDetails) {
    this.apply = false;
    sessionStorage.setItem('RequirementDetails', JSON.stringify(requirementDetails));
    
    
    this.router.navigate(['candidatedetails/candidateapplicationform', requirementDetails.jobId]);

    // this.jobId = this.route.snapshot.params['jobId'];
    // console.log(jobId);
    // this.router.navigate(['candidatedetails/candidateapplicationform']);
  }



  // uploadDocuments(){

  // }
}
