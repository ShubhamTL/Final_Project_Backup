import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { CandidateDetails } from 'src/app/pojo/candidate-details';
import { FileDetails } from 'src/app/pojo/file-details';

import { RequirementDetails } from 'src/app/pojo/requirement-details';
import { CandidateDetailsService } from 'src/app/services/candidate-details.service';
import { FileDetailsService } from 'src/app/services/file-details.service';
import { RequirementDetailsService } from 'src/app/services/requirement-details.service';


@Component({
  selector: 'app-candidate-application-form',
  templateUrl: './candidate-application-form.component.html',
  styleUrls: ['./candidate-application-form.component.css']
})
export class CandidateApplicationFormComponent implements OnInit {
  // fileDetails: FileDetails = new FileDetails();
  // selectedFiles?: FileList;
  // currentFile?: File;
  // progress = 0;
  // message = '';
  // fileInfos?: Observable<any>;
  candidateDetails: CandidateDetails = new CandidateDetails();
  requirmentDetails: RequirementDetails = new RequirementDetails();
  jobId: number = 0;
  applied: boolean = false;
  constructor(private router: Router, private candidatedetailsService: CandidateDetailsService, private route: ActivatedRoute, private uploadService: FileDetailsService) { }

  ngOnInit(): void {
   
    
    this.requirmentDetails = JSON.parse(sessionStorage.getItem('RequirementDetails') || '{}');
    this.jobId = this.requirmentDetails.jobId;
    this.jobId = this.route.snapshot.params['jobId'];
   
    
  }


  onFormSubmit() {
    this.applied = true;
    this.candidateDetails.requirementDetails = this.requirmentDetails;
    //this.candidateDetails.fileDetails = this.fileDetails;
    this.candidatedetailsService.addCandidateApplication(this.candidateDetails).subscribe(data => {
    
    }
    )
  }

  // selectFile(event: any): void {
  //   this.selectedFiles = event.target.files;
  // }

  // // OnClick of button Upload
  // upload(): void {
  //   if (this.selectedFiles) {
  //     const file: File | null = this.selectedFiles.item(0);
  //     if (file) {
  //       this.currentFile = file;
  //       this.uploadService.upload(this.currentFile).subscribe(data => {
  //         this.fileDetails.fileId = data;
  //         this.message = 'File Uploaded successfully!';
  //       });
  //     }
  //   }
  // }

  goToHomePage() {
   this.router.navigate(['candidatedetails']);

  }
}
