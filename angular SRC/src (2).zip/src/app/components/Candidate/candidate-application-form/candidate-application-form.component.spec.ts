import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CandidateApplicationFormComponent } from './candidate-application-form.component';

describe('CandidateApplicationFormComponent', () => {
  let component: CandidateApplicationFormComponent;
  let fixture: ComponentFixture<CandidateApplicationFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CandidateApplicationFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CandidateApplicationFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
