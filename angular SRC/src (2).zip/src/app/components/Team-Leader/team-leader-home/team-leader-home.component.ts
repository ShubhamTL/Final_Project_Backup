import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-team-leader-home',
  templateUrl: './team-leader-home.component.html',
  styleUrls: ['./team-leader-home.component.css']
})
export class TeamLeaderHomeComponent implements OnInit {
hide:boolean=true;
  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  onclick(){
this.hide=false;
  }

  logout(){
    this.router.navigate(['logindetails'])
  }

}
