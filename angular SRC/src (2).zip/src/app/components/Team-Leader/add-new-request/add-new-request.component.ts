import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/employee-details';
import { RequirementDetails } from 'src/app/pojo/requirement-details';
import { RequirementDetailsService } from 'src/app/services/requirement-details.service';

@Component({
  selector: 'app-add-new-request',
  templateUrl: './add-new-request.component.html',
  styleUrls: ['./add-new-request.component.css']
})
export class AddNewRequestComponent implements OnInit {

  submitted: boolean = false;
  result: boolean = false;
  requirementDetails: RequirementDetails = new RequirementDetails();
  employee : EmployeeDetails = new EmployeeDetails();
  hide:boolean=false;
  constructor(private requirementDetailsService: RequirementDetailsService, private router: Router) { }

  ngOnInit(): void {
    this.employee =  JSON.parse(sessionStorage.getItem('employee') || '{}');
    
    this.requirementDetails.employeeDetails = this.employee;
    this.requirementDetails.projectMaster = this.employee.projectMaster;
    
      
  }
  goToPage()
  {
   this.router.navigate(['teamleaderhome/viewjobrequest']);
  }
  onFormSubmit() {
    this.submitted = true;

    this.requirementDetailsService.addRequirementDetails(this.requirementDetails).subscribe(data => {
      this.result = data;
    }
    );
  }
}
