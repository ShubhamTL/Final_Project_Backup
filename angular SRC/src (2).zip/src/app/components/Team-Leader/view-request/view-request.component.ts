import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/employee-details';
import { RequirementDetails } from 'src/app/pojo/requirement-details';
import { RequirementDetailsService } from 'src/app/services/requirement-details.service';

@Component({
  selector: 'app-view-request',
  templateUrl: './view-request.component.html',
  styleUrls: ['./view-request.component.css']
})
export class ViewRequestComponent implements OnInit {

  requirementDetails: RequirementDetails = new RequirementDetails();
  employee : EmployeeDetails = new EmployeeDetails();
  inproccessJobRequest: RequirementDetails[]=[];
  sendToHRJobRequest: RequirementDetails[]=[];
  acceptedJobRequest: RequirementDetails[]=[];
  inprocessrecordFound:boolean=false;
  sendToHrRecordFound:boolean=false;
  acceptedRecordFound:boolean=false;
  constructor(private requirmentDetailsService: RequirementDetailsService,private router:Router)
   {

  }

  ngOnInit(): void {
    this.reloadData1();
    this.reloadData2();
    this.reloadData3();

  
  }
  

  reloadData1() {
    this.requirmentDetailsService.getRequirementDetailsByInProcess().subscribe(data => {
    
      
      if(data.length>=1){
        this.inprocessrecordFound=true;
      this.inproccessJobRequest = data;
    
      }
      else{
        this.inprocessrecordFound=false;
      }
    }
    );
  }
  reloadData2(){
    this.requirmentDetailsService.getRequirementDetailsBySendToHR().subscribe(data => {

      if(data.length>=1){
        this.sendToHrRecordFound=true;
      this.sendToHRJobRequest = data;
    
      }
     
    }
    );
  }
  reloadData3(){
    this.requirmentDetailsService.getRequirementByAcceptedStatus().subscribe(data => {
      if(data.length>=1){
        this.acceptedRecordFound=true;
      this.acceptedJobRequest = data;
    
      }
     
    }
    );
  }

 

  

}
