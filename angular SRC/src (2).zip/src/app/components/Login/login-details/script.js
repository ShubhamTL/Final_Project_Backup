
function validate() {
 var loginId = document.forms["myform"]["loginId"].value;
 if(loginId==""){
 alert("Please enter the loginId");
 return false;
 }
 var password = document.forms["myform"]["password"].value;
 if(password==""){
 alert("Please enter the password");
 return false;
 }
}