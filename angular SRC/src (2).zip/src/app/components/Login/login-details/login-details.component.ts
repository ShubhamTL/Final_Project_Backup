import { IfStmt } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/employee-details';
import { LoginDetails } from 'src/app/pojo/login-details';
import { EmployeeDetailsService } from 'src/app/services/employee-details.service';
import { LoginDetailsService } from 'src/app/services/login-details.service';

@Component({
  selector: 'app-login-details',
  templateUrl: './login-details.component.html',
  styleUrls: ['./login-details.component.css']
})
export class LoginDetailsComponent implements OnInit {

  submitted: boolean = false;
  loginDetails: LoginDetails = new LoginDetails();
  employeeDetails: EmployeeDetails = new EmployeeDetails();

  loginForm=new FormGroup({
    loginId:new FormControl('',[Validators.required]),
    password:new FormControl('',[Validators.required]),
  });


  constructor(private loginDetailService: LoginDetailsService, private employeeDetailsService: EmployeeDetailsService, private router: Router) { }

  ngOnInit(): void {
  }
  // goToPage()
  // {
  //  this.router.navigate(['getrequirementdetails']);
  // }

  onFormSubmit() {
    this.submitted = true;
    this.loginDetailService.validateLogin(this.loginDetails).subscribe(data => {
      this.loginDetails = data;

      this.employeeDetailsService.getEmployeeByLoginId(this.loginDetails.loginId).subscribe(data => {
        this.employeeDetails = data;
        sessionStorage.setItem('employee', JSON.stringify(this.employeeDetails));
      }
      );

      if (this.loginDetails.role === 'HR') {
        this.router.navigate(['hrhome']);
      }
      if (this.loginDetails.role === 'TEAM LEADER') {
        this.router.navigate(['teamleaderhome']);
      }
      if (this.loginDetails.role === 'INTERVIEWER') {
        this.router.navigate(['interviewerhome']);
      }
      if (this.loginDetails.role === 'PROJECT MANAGER') {
        this.router.navigate(['projectmanagerhome']);
      }
    }
    );
    // alert("Form submitted Successfully !!");


  }
}
