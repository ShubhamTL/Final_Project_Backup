import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CandidateDetails } from 'src/app/pojo/candidate-details';
import { RequirementDetails } from 'src/app/pojo/requirement-details';
import { CandidateDetailsService } from 'src/app/services/candidate-details.service';

@Component({
  selector: 'app-update-candidate-details',
  templateUrl: './update-candidate-details.component.html',
  styleUrls: ['./update-candidate-details.component.css']
})
export class UpdateCandidateDetailsComponent implements OnInit {

  candidateDetails:CandidateDetails=new CandidateDetails();
  requirementDetails:RequirementDetails=new RequirementDetails();
  newApplications:CandidateDetails[]=[];
  sendToInterviewerApplications:CandidateDetails[]=[];
  selectedApplications:CandidateDetails[]=[];
  rejectedApplications:CandidateDetails[]=[];
  jobId:number=0;
  inproccessRecordFound:boolean=false;
  sendToInterviewerRecordFound:boolean=false;
  selectedRecordFound:boolean=false;
  rejectedRecordFound:boolean=false;
  constructor( private candidateDetailsService:CandidateDetailsService, private router:Router) { }

  ngOnInit(): void {
    this.jobId=this.requirementDetails.jobId;
    this.reloadData1();
    
   
   
  }

  sendToInterviewer(candidateDetails:CandidateDetails){
    // candidateDetails.applicationStatus='SEND TO INTERVIEWER';
   
    // this.reloadData2();
      this.candidateDetailsService.updateCandidateStatus(candidateDetails).subscribe(data => {
   
      }
      );
      this.reloadData1();
      // this.router.navigate(['hrhome/updatecandidatedetails']); 
     
  }
  // rejectApplicatioin(candidateDetails:CandidateDetails){
  //   candidateDetails.applicationStatus='REJECT';
  //     this.candidateDetailsService.updateCandidateStatus(candidateDetails).subscribe(data => {
  //       console.log(data);
  //     }
  //     );
  //     this.router.navigate(['hrhome/updatecandidatedetails']); 
  // }
  reloadData1(){
    this.candidateDetailsService.getAllCandidateDetails().subscribe(data=>{
   
        this.inproccessRecordFound=true;
     this.newApplications=data;
      

     
    }
    );
  }
  // reloadData2(){
  //   this.candidateDetailsService.getCandidateDetailsByStatus().subscribe(data=>{
  //     if(data.length>0){
  //       this.sendToInterviewerRecordFound=true;
  //    this.sendToInterviewerApplications=data;
  //     }
  //    else
  //    this.sendToInterviewerRecordFound=false;
  //   }
  //   );
  // }
   
    // this.candidateDetailsService.getCandidateDetailsBySelectedStatus().subscribe(data=>{
    //   if(data.length>0){
    //     this.selectedRecordFound=true;
    //  this.selectedApplications=data;
    //   }

    //  else
    //  this.selectedRecordFound=false;
    // }
    // );
    
    // this.candidateDetailsService.getCandidateDetailsByRejectedStatus().subscribe(data=>{
    //   if(data.length>0){
    //     this.rejectedRecordFound=true;
    //  this.rejectedApplications=data;
    //   }

    //  else
    //  this.rejectedRecordFound=false;
    // }
    // );
    
  // }

}
