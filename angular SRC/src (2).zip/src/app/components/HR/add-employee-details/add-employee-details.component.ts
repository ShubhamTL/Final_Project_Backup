import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/employee-details';
import { EmployeeDetailsService } from 'src/app/services/employee-details.service';

@Component({
  selector: 'app-add-employee-details',
  templateUrl: './add-employee-details.component.html',
  styleUrls: ['./add-employee-details.component.css']
})
export class AddEmployeeDetailsComponent implements OnInit {

 
  submitted: boolean = false;
  result: boolean = false;
  employeeDetails: EmployeeDetails = new EmployeeDetails();
  employee : EmployeeDetails = new EmployeeDetails();
  projectId:number=0;
  loginId:number=0;
  constructor(private employeeDetailService: EmployeeDetailsService, private router: Router) { }

  ngOnInit(): void {
    this.employee =  JSON.parse(sessionStorage.getItem('employee') || '{}');
    this.projectId = this.employee.projectMaster.projectId;
    this.loginId=this.employee.loginDetails.loginId;
   
  
    // //this.requirementDetails.employeeDetails.employeeId = this.employee.employeeId;
    // //this.requirementDetails.projectMaster.projectId = this.employee.projectMaster.projectId;
    
  }
  goToPage()
  {
   this.router.navigate(['getrequirementdetails']);
  }
  onFormSubmit() {
    this.submitted = true;
    this.employeeDetailService.addEmployeeDetails(this.employeeDetails).subscribe(data => {
      this.result = data;
    }
    );
  }

}
