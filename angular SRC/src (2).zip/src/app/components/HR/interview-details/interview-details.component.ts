import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InterviewDetails } from 'src/app/pojo/interview-details';
import { InterviewDetailsService } from 'src/app/services/interview-details.service';

@Component({
  selector: 'app-interview-details',
  templateUrl: './interview-details.component.html',
  styleUrls: ['./interview-details.component.css']
})
export class InterviewDetailsComponent implements OnInit {
  selectedInterviewDetails: InterviewDetails[] = [];
  rejectedInterviewDetails: InterviewDetails[] = [];
  selectedRecordFound: boolean = false;
  rejectedRecordFound: boolean = false;
  constructor(private interviewDetailsService: InterviewDetailsService, private router: Router) { }

  ngOnInit(): void {
    this.reloadData();

  }
  

  reloadData() {
    this.interviewDetailsService.getSelectedInterviewDetails().subscribe(data => {
      if (data.length >= 1) {
        this.selectedRecordFound = true;
        this.selectedInterviewDetails = data;
      }

    }
    );

    this.interviewDetailsService.getRejectedInterviewDetails().subscribe(data => {
      if(data.length>=1){
        this.rejectedRecordFound=true;
      this.rejectedInterviewDetails=data;
    
      }
   }
     );
  }

  sendSelectResult(interviewDetails: InterviewDetails) {
    console.log(interviewDetails);
    this.interviewDetailsService.sendInterviewResult(interviewDetails).subscribe(data => {
    }

    );
  }
  sendRejectResult(interviewDetails: InterviewDetails) {    
    this.interviewDetailsService.sendInterviewResult(interviewDetails).subscribe(data => {
    }
    );
  }
}
