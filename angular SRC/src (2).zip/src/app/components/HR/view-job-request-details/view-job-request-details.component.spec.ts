import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewJobRequestDetailsComponent } from './view-job-request-details.component';

describe('ViewJobRequestDetailsComponent', () => {
  let component: ViewJobRequestDetailsComponent;
  let fixture: ComponentFixture<ViewJobRequestDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewJobRequestDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewJobRequestDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
