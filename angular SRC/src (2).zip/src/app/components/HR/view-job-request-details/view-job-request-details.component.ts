import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/employee-details';
import { RequirementDetails } from 'src/app/pojo/requirement-details';
import { RequirementDetailsService } from 'src/app/services/requirement-details.service';

@Component({
  selector: 'app-view-job-request-details',
  templateUrl: './view-job-request-details.component.html',
  styleUrls: ['./view-job-request-details.component.css']
})
export class ViewJobRequestDetailsComponent implements OnInit {

  requirementDetails: RequirementDetails = new RequirementDetails();
  employee : EmployeeDetails = new EmployeeDetails();
  sendToHrJobRequest: RequirementDetails[]=[];
  acceptedJobRequest:RequirementDetails[]=[];
  sendToHrrecordFound:boolean=false;
  acceptedrecordFound:boolean=false;
  constructor(private requirmentDetailsService: RequirementDetailsService,private router:Router) { }
  ngOnInit(): void {
    
    this.reloadData();
  }
  reloadData() {
    this.requirmentDetailsService.getRequirementDetailsBySendToHR().subscribe(data => {
      if(data.length>=1){
      this.sendToHrJobRequest = data;
      this.sendToHrrecordFound=true;
      console.log(this.sendToHrJobRequest);
      }
      else{
        this.sendToHrrecordFound=false;
      }
    }
    );

    this.requirmentDetailsService.getRequirementByAcceptedStatus().subscribe(data => {
      if(data.length>=1){
      this.acceptedJobRequest = data;
      this.acceptedrecordFound=true;
  
      }
      else{
        this.acceptedrecordFound=false;
      }
    }
    );
  }
  
  uploadRequirement(requirementdetail:RequirementDetails){
    this.requirmentDetailsService.acceptJobRequirement(requirementdetail).subscribe(data => {
      this.reloadData();
    }
    );
    this.router.navigate(['hrhome/viewjobrequestdetails']); 
  }
}
