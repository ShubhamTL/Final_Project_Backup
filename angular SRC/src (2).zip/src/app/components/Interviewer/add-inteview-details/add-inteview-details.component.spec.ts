import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddInteviewDetailsComponent } from './add-inteview-details.component';

describe('AddInteviewDetailsComponent', () => {
  let component: AddInteviewDetailsComponent;
  let fixture: ComponentFixture<AddInteviewDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddInteviewDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddInteviewDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
