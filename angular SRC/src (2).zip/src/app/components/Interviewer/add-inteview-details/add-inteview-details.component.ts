import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CandidateDetails } from 'src/app/pojo/candidate-details';
import { EmployeeDetails } from 'src/app/pojo/employee-details';
import { InterviewDetails } from 'src/app/pojo/interview-details';
import { InterviewDetailsService } from 'src/app/services/interview-details.service';

@Component({
  selector: 'app-add-inteview-details',
  templateUrl: './add-inteview-details.component.html',
  styleUrls: ['./add-inteview-details.component.css']
})
export class AddInteviewDetailsComponent implements OnInit {
  candidateDetails:CandidateDetails=new CandidateDetails();
  employee:EmployeeDetails=new EmployeeDetails();
  submitted: boolean = false;
  candidateId:number=0;
  interviewDetails:InterviewDetails=new InterviewDetails();
  constructor(private interviewDetailsService:InterviewDetailsService,private router:Router,private route:ActivatedRoute) { }

  ngOnInit(): void {
    this.candidateId = this.route.snapshot.params['candidateId'];
   
  
  
   
   this.employee =  JSON.parse(sessionStorage.getItem('employee') || '{}');
    this.candidateDetails.candidateId=this.candidateId;

  this.interviewDetails.employeeDetails=this.employee;
  this.interviewDetails.candidateDetails=this.candidateDetails;

  }
  onFormSubmit() {
    this.submitted = true;
    this.interviewDetails.candidateDetails=this.candidateDetails;
    this.interviewDetailsService.addNewInterview(this.interviewDetails).subscribe(data => {
      
    }
    );
  }

 

  goToPage(){
    this.router.navigate(['interviewerhome/viewcandidatedetails']);
  }

}
