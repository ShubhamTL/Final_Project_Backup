import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CandidateDetails } from 'src/app/pojo/candidate-details';
import { RequirementDetails } from 'src/app/pojo/requirement-details';
import { CandidateDetailsService } from 'src/app/services/candidate-details.service';
import { InterviewDetailsService } from 'src/app/services/interview-details.service';

@Component({
  selector: 'app-view-candidate-details',
  templateUrl: './view-candidate-details.component.html',
  styleUrls: ['./view-candidate-details.component.css']
})
export class ViewCandidateDetailsComponent implements OnInit {

  
  candidateDetails:CandidateDetails=new CandidateDetails();
  requirementDetails:RequirementDetails=new RequirementDetails();
  applications:CandidateDetails[]=[];
  jobId:number=0;
  candidateId:number=0;
  constructor( private candidateDetailsService:CandidateDetailsService,private interviewDetailsService:InterviewDetailsService, private router:Router) { }

  ngOnInit(): void {
   this.jobId=this.requirementDetails.jobId;
   this.candidateDetailsService.getCandidateDetailsByStatus().subscribe(data=>{
    this.applications=data;
   }
   );
   
  }

  interviewForm(candidateDetails:CandidateDetails){
 this.candidateId= candidateDetails.candidateId ;
 this.router.navigate(['interviewerhome/addinterviewdetails',this.candidateId]);

  }
}
