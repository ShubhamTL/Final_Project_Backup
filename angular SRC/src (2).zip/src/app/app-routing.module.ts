import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { CandidateApplicationFormComponent } from './components/Candidate/candidate-application-form/candidate-application-form.component';
import { CandidateHomeComponent } from './components/Candidate/candidate-home/candidate-home.component';
import { AddEmployeeDetailsComponent } from './components/HR/add-employee-details/add-employee-details.component';
import { HrHomeComponent } from './components/HR/hr-home/hr-home.component';
import { InterviewDetailsComponent } from './components/HR/interview-details/interview-details.component';
import { UpdateCandidateDetailsComponent } from './components/HR/update-candidate-details/update-candidate-details.component';
import { ViewJobRequestDetailsComponent } from './components/HR/view-job-request-details/view-job-request-details.component';
import { AddInteviewDetailsComponent } from './components/Interviewer/add-inteview-details/add-inteview-details.component';
import { InterviewHomeComponent } from './components/Interviewer/interview-home/interview-home.component';
import { ViewCandidateDetailsComponent } from './components/Interviewer/view-candidate-details/view-candidate-details.component';
import { LoginDetailsComponent } from './components/Login/login-details/login-details.component';
import { AddNewProjectComponent } from './components/Project-Manager/add-new-project/add-new-project.component';
import { CheckOnBenchComponent } from './components/Project-Manager/check-on-bench/check-on-bench.component';
import { EmployeeDetailsComponent } from './components/Project-Manager/employee-details/employee-details.component';
import { ProjectManagerHomeComponent } from './components/Project-Manager/project-manager-home/project-manager-home.component';
import { UpdateJobRequestComponent } from './components/Project-Manager/update-job-request/update-job-request.component';
import { AddNewRequestComponent } from './components/Team-Leader/add-new-request/add-new-request.component';
import { TeamLeaderHomeComponent } from './components/Team-Leader/team-leader-home/team-leader-home.component';
import { ViewRequestComponent } from './components/Team-Leader/view-request/view-request.component';
const routes: Routes = [
  { path: 'appcomponent', component: AppComponent },

  {
    path: 'candidatedetails', component: CandidateHomeComponent,
    children: [
      { path: 'candidateapplicationform/:jobId', component: CandidateApplicationFormComponent }
    ]
  },
  { path: 'logindetails', component: LoginDetailsComponent },

  {
    path: 'hrhome', component: HrHomeComponent,
    children: [
      { path: 'viewjobrequestdetails', component: ViewJobRequestDetailsComponent },
      { path: 'updatecandidatedetails', component: UpdateCandidateDetailsComponent },
      { path: 'addnewemployeedetails', component: AddEmployeeDetailsComponent },
      { path: 'interviewdetails', component: InterviewDetailsComponent },

    ]
  },
  {
    path: 'teamleaderhome', component: TeamLeaderHomeComponent,
    children: [
      { path: 'addnewjobrequest', component: AddNewRequestComponent },
      { path: 'viewjobrequest', component: ViewRequestComponent }
    ]
  },

  {
    path: 'projectmanagerhome', component: ProjectManagerHomeComponent,
    children: [
      { path: 'addnewproject', component: AddNewProjectComponent },
      { path: 'employeedetails', component: EmployeeDetailsComponent },
      { path: 'updatejobrequestdetails', component: UpdateJobRequestComponent },
      { path: 'checkonbench/:jobId', component: CheckOnBenchComponent }
    ]
  },

  {
    path: 'interviewerhome', component: InterviewHomeComponent,
    children: [
      { path: 'addinterviewdetails/:candidateId', component: AddInteviewDetailsComponent },
      { path: 'viewcandidatedetails', component: ViewCandidateDetailsComponent }
    ]
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
