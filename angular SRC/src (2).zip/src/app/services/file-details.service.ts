import { HttpClient, HttpEvent, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { FileDetails } from '../pojo/file-details';

@Injectable({
  providedIn: 'root'
})
export class FileDetailsService {


  private baseUrl = 'http://localhost:8080/filedetails';
  constructor(private http: HttpClient) { }
  upload(file: File): Observable<number> {
    const formData: FormData = new FormData();
    formData.append('file', file);
    // const req = new HttpRequest('POST', `${this.baseUrl}/filesdetails`, formData, {
    //   reportProgress: true,
    //   responseType: 'json'
    // });
    return this.http.post<number>(`${this.baseUrl}/filesdetails`, formData, {
      reportProgress: true,
      responseType: 'json'
    });
  }

}
