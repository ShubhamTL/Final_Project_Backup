import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { RequirementDetails } from '../pojo/requirement-details';


@Injectable({
  providedIn: 'root'
})
export class RequirementDetailsService{
  allRequirements : Observable<RequirementDetails[]> = new Observable<RequirementDetails[]>();
  baseURL: string = "http://localhost:8080/requirementdetails";
  //baseURL1: string = "http://localhost:8080/requirementdetails/requirementdetailbyprojectid";
  
  constructor( private http:HttpClient) { }

  getAllRequirementDetails(): Observable<RequirementDetails[]> {
    return this.http.get<RequirementDetails[]>(this.baseURL+'/requirementdetail');
  }

  getSinglRequirementDetails(jobId:number):Observable<RequirementDetails>
  {
    console.log("getSingle Requirement Details"+jobId);
    return this.http.get<RequirementDetails>(this.baseURL +'/requirementdetail/'+ jobId);
  }
  addRequirementDetails(requirementDetails: RequirementDetails): Observable<boolean> {
    console.log(requirementDetails);
    return this.http.post<boolean>(this.baseURL+'/requirementdetail', requirementDetails);
  }

  deleteJobRequest(jobId:number):Observable<boolean>{
    return this.http.delete<boolean>(this.baseURL+'/requirementdetail/'+ jobId);
  }

  getRequirmentByProjectId(projectId:number):Observable<RequirementDetails[]>{
    console.log("in service");
    console.log(projectId); 
    return this.http.get<RequirementDetails[]>(this.baseURL+'/requirementdetailbyprojectid/'+projectId);
  }
  sendToHrUpdateByJobId(requirementdetail:RequirementDetails):Observable<boolean>{
    return this.http.put<boolean>(this.baseURL+'/updaterequirementdetailstatus',requirementdetail);
  }
  
  getRequirementByStatus():Observable<RequirementDetails[]>{
    return this.http.get<RequirementDetails[]>(this.baseURL+'/requirementdetailstatus');
  }

  acceptJobRequirement(requirementdetail:RequirementDetails):Observable<boolean>{
    return this.http.put<boolean>(this.baseURL+'/updaterequirementdetailstatustoaccepted',requirementdetail);
  }
  getRequirementByAcceptedStatus():Observable<RequirementDetails[]>{
    return this.http.get<RequirementDetails[]>(this.baseURL+'/requirementdetailbyacceptedstatus');
  }

  getRequirementDetailsByInProcess():Observable<RequirementDetails[]>{
    return this.http.get<RequirementDetails[]>(this.baseURL+'/requirementdetailbyinprocessstatus')

  }

  getRequirementDetailsBySendToHR():Observable<RequirementDetails[]>{
    return this.http.get<RequirementDetails[]>(this.baseURL+'/requirementdetailbysendtohrstatus');
  }

}
