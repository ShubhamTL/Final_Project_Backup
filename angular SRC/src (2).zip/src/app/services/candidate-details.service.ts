import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CandidateDetails } from '../pojo/candidate-details';

@Injectable({
  providedIn: 'root'
})
export class CandidateDetailsService {

  
baseURL: string = "http://localhost:8080/candidatedetails/";
constructor( private http:HttpClient) { }

getAllCandidateDetails(): Observable<CandidateDetails[]> {
  return this.http.get<CandidateDetails[]>(this.baseURL+'candidatedetail');
}

getSinglCandidateDetails(candidateId:number):Observable<CandidateDetails>
{
  console.log("getSingle Candidate Details"+candidateId);
  return this.http.get<CandidateDetails>(this.baseURL +'candidatedetail/'+ candidateId);
}

addCandidateApplication(candidateDetails:CandidateDetails):Observable<boolean>{
return this.http.post<boolean>(this.baseURL+'candidatedetail',candidateDetails);
}

updateCandidateStatus(candidateDetails:CandidateDetails):Observable<boolean>{
  return this.http.put<boolean>(this.baseURL+'updatecandidatedetailsstatusbyid',candidateDetails);
}

getCandidateDetailsByinprocessStatus():Observable<CandidateDetails[]>{
  return this.http.get<CandidateDetails[]>(this.baseURL+'getcandidatedetailsbyinprocessstatus');

}
getCandidateDetailsByStatus():Observable<CandidateDetails[]>{
  return this.http.get<CandidateDetails[]>(this.baseURL+'getcandidatedetailsbysendtointerviewerstatus ');

}
getCandidateDetailsBySelectedStatus():Observable<CandidateDetails[]>{
  return this.http.get<CandidateDetails[]>(this.baseURL+'getcandidatedetailsbyselectedstatus');

}
getCandidateDetailsByRejectedStatus():Observable<CandidateDetails[]>{
  return this.http.get<CandidateDetails[]>(this.baseURL+'getcandidatedetailsbyrejectedstatus');

}

}
