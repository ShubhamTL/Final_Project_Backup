import { TestBed } from '@angular/core/testing';

import { RequirementDetailsService } from './requirement-details.service';

describe('RequirementDetailsService', () => {
  let service: RequirementDetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RequirementDetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
