import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { LoginDetails } from '../pojo/login-details';

@Injectable({
  providedIn: 'root'
})
export class LoginDetailsService {

  baseURL: string = "http://localhost:8080/logindetails/logindetail";
  constructor(private http:HttpClient) { }

  getAllLoginDetails(): Observable<LoginDetails[]> {
    return this.http.get<LoginDetails[]>(this.baseURL);
  }

  getSingleLoginDetails(loginId:number):Observable<LoginDetails>
  {
    console.log("getSingle Login Details"+loginId);
    return this.http.get<LoginDetails>(this.baseURL +'/'+ loginId);
  }

  validateLogin(loginDetails : LoginDetails) : Observable<LoginDetails>{
    return this.http.post<LoginDetails>(this.baseURL,loginDetails);
  }
  // addLoginDetails(loginDetails: LoginDetails): Observable<boolean> {
  //   console.log("in EmployeeCRUDService");
  //   console.log(loginDetails);
  //   return this.http.post<boolean>(this.baseURL, loginDetails);
  //   console.log("EmployeeCRUDService End")
  // }
}
