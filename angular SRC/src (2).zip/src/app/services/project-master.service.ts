import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ProjectMaster } from '../pojo/project-master';


@Injectable({
  providedIn: 'root'
})
export class ProjectMasterService{

 
  baseURL: string = "http://localhost:8080/projectmasterdetails/projectmaster";
  constructor( private http:HttpClient) { }

  getAllProjectMaster(): Observable<ProjectMaster[]> {
    return this.http.get<ProjectMaster[]>(this.baseURL);
  }

  getSinglProjectMaster(projectId:number):Observable<ProjectMaster>
  {
    console.log("getSingle Project Master"+projectId);
    return this.http.get<ProjectMaster>(this.baseURL +'/'+ projectId);
  }
  addNewProject(projectMaster: ProjectMaster): Observable<boolean> {
    console.log(projectMaster);
    return this.http.post<boolean>(this.baseURL, projectMaster);
  }
}
