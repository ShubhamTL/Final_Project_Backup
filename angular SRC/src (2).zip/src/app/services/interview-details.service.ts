import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { InterviewDetails } from '../pojo/interview-details';
import { ProjectMaster } from '../pojo/project-master';

@Injectable({
  providedIn: 'root'
})
export class InterviewDetailsService {

  baseURL: string = "http://localhost:8080/interviewdetails/";
  constructor( private http:HttpClient) { }

  getAllInterviewDetails(): Observable<InterviewDetails[]> {
    return this.http.get<InterviewDetails[]>(this.baseURL+'interviewdetail');
  }

  getSinglInterviewDetails(interviewId:number):Observable<InterviewDetails>
  {
    console.log("getSingle Interview Details"+interviewId);
    return this.http.get<InterviewDetails>(this.baseURL +'interviewdetail/'+ interviewId);
  }
  addNewInterview(interviewDetails:InterviewDetails):Observable<boolean>{
return this.http.post<boolean>(this.baseURL+'interviewdetail',interviewDetails);

  }
  getSelectedInterviewDetails(): Observable<InterviewDetails[]> {
    return this.http.get<InterviewDetails[]>(this.baseURL+'getinterviewdetailsbyselectedstatus');
  }
  getRejectedInterviewDetails(): Observable<InterviewDetails[]> {
    return this.http.get<InterviewDetails[]>(this.baseURL+'getinterviewdetailsbyrejectedstatus');
  }

  sendInterviewResult(interviewDetail:InterviewDetails):Observable<boolean>{
    return this.http.post<boolean>(this.baseURL+'sendmail',interviewDetail);
  }
  
}
 