import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EmployeeDetails } from '../pojo/employee-details';
import { RequirementDetails } from '../pojo/requirement-details';

@Injectable({
  providedIn: 'root'
})
export class EmployeeDetailsService {


  baseURL: string = "http://localhost:8080/employeedetails";

  constructor(private http: HttpClient) { }

  getAllEmployeeDetails(): Observable<EmployeeDetails[]> {
    return this.http.get<EmployeeDetails[]>(this.baseURL + '/employeedetail');
  }

  getSinglEmployeeDetails(employeeId: number): Observable<EmployeeDetails> {
    console.log("getSingle Employee Details" + employeeId);
    return this.http.get<EmployeeDetails>(this.baseURL + '/employeedetail/' + employeeId);
  }

  getEmployeeByLoginId(loginId: number): Observable<EmployeeDetails> {
    return this.http.get<EmployeeDetails>(this.baseURL + '/employeedetail/' + loginId);
  }

  addEmployeeDetails(employeeDetail: EmployeeDetails): Observable<boolean> {
    return this.http.post<boolean>(this.baseURL + '/employeedetail', employeeDetail);
  }
  getEmployeeOnBench(requirementDetails: RequirementDetails): Observable<EmployeeDetails[]> {
    console.log("in EmployeeDetailsService");
    console.log(requirementDetails);    
    return this.http.post<EmployeeDetails[]>(this.baseURL + '/employeedetailemployeeOnBench/', requirementDetails);
  }

  assignProjectByemployeeId(employeeDetail:EmployeeDetails):Observable<boolean>{
    console.log('assignProjectByemployeeId');
    return this.http.put<boolean>(this.baseURL+'/updateemployeeprojectid',employeeDetail);
  }
}
