import { CandidateDetails } from "./candidate-details";
import { EmployeeDetails } from "./employee-details";

export class InterviewDetails{
    interviewId:number=0;
    aptitudeRound:number=0;
    technicalRound:number=0;
    hrRound:number=0;
    remarks:string="";
    interviewStatus:string="";
    employeeDetails:EmployeeDetails =new EmployeeDetails();
    candidateDetails: CandidateDetails=new CandidateDetails();
}