import { CandidateDetails } from "./candidate-details";

export class FileDetails{
    fileId:number=0;
    fileName:string="";
    fileType:string="";
    
}