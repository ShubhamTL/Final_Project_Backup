import { EmployeeDetails } from "./employee-details";
import { ProjectMaster } from "./project-master";

export class RequirementDetails{
    jobId:number=0;
    qualification:string="";
    primarySkill1:string="";
    primarySkill2:string="";
    primarySkill3:string="";
    jobRequestStatus:string='IN_PROCESS';
    experience:number=0;
    requiredNoOfEmployees:number=0;
    employeeDetails : EmployeeDetails=new EmployeeDetails();
    projectMaster : ProjectMaster=new ProjectMaster();
    
}