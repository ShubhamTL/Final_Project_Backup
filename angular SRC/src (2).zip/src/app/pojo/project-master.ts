export class ProjectMaster{
    projectId:number=0;
    projectName:string="";
    startDate: Date= new Date();
    endDate:Date=new Date();
}