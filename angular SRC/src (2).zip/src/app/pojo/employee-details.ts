import { LoginDetails } from "./login-details";
import { ProjectMaster } from "./project-master";

export class EmployeeDetails{
    employeeId: number=0;
    firstName: string="";
    lastName: string="";
    emailId: string="";
    contactNo: number=0;
    gender:string="";
    dateOfBirth:Date=new Date();
    dateOfJoining:Date=new Date();
    designation:string="";
    qualification:string="";
    primarySkill1:string="";
    primarySkill2:string="";
    primarySkill3:string="";
    mgrId:number=0;
    loginDetails:LoginDetails=new LoginDetails();
    projectMaster: ProjectMaster=new ProjectMaster();
    
}