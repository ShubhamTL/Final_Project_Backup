export class LoginDetails{
    loginId:number=0;
    role:string="";
    password:string="";
}