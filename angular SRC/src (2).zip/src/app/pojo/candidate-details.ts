import { formatDate } from "@angular/common";
import { FileDetails } from "./file-details";
import { RequirementDetails } from "./requirement-details";

export class CandidateDetails{
    candidateId:number=0;
    firstName:string="";
    lastName:string="";
    emailId:string="";
    contactNo:number=0;
    dateOfBirth:Date=new Date();
    qualification:string="";
    experience:number=0;
    primarySkill1:string="";
    primarySkill2:string="";
    primarySkill3:string="";
    applicationStatus:string='IN_PROCESS';
    requirementDetails:RequirementDetails =new RequirementDetails();
    fileDetails: FileDetails = new FileDetails();
}