import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import{ HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginDetailsComponent } from './components/Login/login-details/login-details.component';
import { TeamLeaderHomeComponent } from './components/Team-Leader/team-leader-home/team-leader-home.component';
import { HrHomeComponent } from './components/HR/hr-home/hr-home.component';
import { ProjectManagerHomeComponent } from './components/Project-Manager/project-manager-home/project-manager-home.component';
import { InterviewHomeComponent } from './components/Interviewer/interview-home/interview-home.component';
import { CandidateHomeComponent } from './components/Candidate/candidate-home/candidate-home.component';
import { AddNewRequestComponent } from './components/Team-Leader/add-new-request/add-new-request.component';
import { AddNewProjectComponent } from './components/Project-Manager/add-new-project/add-new-project.component';
import { EmployeeDetailsComponent } from './components/Project-Manager/employee-details/employee-details.component';
import { UpdateJobRequestComponent } from './components/Project-Manager/update-job-request/update-job-request.component';
import { AddEmployeeDetailsComponent } from './components/HR/add-employee-details/add-employee-details.component';
import { UpdateCandidateDetailsComponent } from './components/HR/update-candidate-details/update-candidate-details.component';
import { ViewJobRequestDetailsComponent } from './components/HR/view-job-request-details/view-job-request-details.component';
import { InterviewDetailsComponent } from './components/HR/interview-details/interview-details.component';
import { AddInteviewDetailsComponent } from './components/Interviewer/add-inteview-details/add-inteview-details.component';
import { ViewCandidateDetailsComponent } from './components/Interviewer/view-candidate-details/view-candidate-details.component';
import { ViewRequestComponent } from './components/Team-Leader/view-request/view-request.component';
import { CheckOnBenchComponent } from './components/Project-Manager/check-on-bench/check-on-bench.component';
import { CandidateApplicationFormComponent } from './components/Candidate/candidate-application-form/candidate-application-form.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginDetailsComponent,
    TeamLeaderHomeComponent,
    HrHomeComponent,
    ProjectManagerHomeComponent,
    InterviewHomeComponent,
    CandidateHomeComponent,
    AddNewRequestComponent,
    AddNewProjectComponent,
    EmployeeDetailsComponent,
    UpdateJobRequestComponent,
    AddEmployeeDetailsComponent,
    UpdateCandidateDetailsComponent,
    ViewJobRequestDetailsComponent,
    InterviewDetailsComponent,
    AddInteviewDetailsComponent,
    ViewCandidateDetailsComponent,
    ViewRequestComponent,
    CheckOnBenchComponent,
    CandidateApplicationFormComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
