--------------------------------------------------------
--  File created - Wednesday-June-22-2022   
--------------------------------------------------------
REM INSERTING into HRPORTAL1.FILE_DETAILS
SET DEFINE OFF;
Insert into HRPORTAL1.FILE_DETAILS (FILE_ID,FILE_NAME,FILE_TYPE) values (624,'index.pdf','application/pdf');
Insert into HRPORTAL1.FILE_DETAILS (FILE_ID,FILE_NAME,FILE_TYPE) values (603,'TEJAS_RESUME','PDF');
Insert into HRPORTAL1.FILE_DETAILS (FILE_ID,FILE_NAME,FILE_TYPE) values (622,'index.pdf','application/pdf');
Insert into HRPORTAL1.FILE_DETAILS (FILE_ID,FILE_NAME,FILE_TYPE) values (606,'SHASHANK_RESUME','PDF');
